import json
import boto3
import uuid
from datetime import datetime

s3 = boto3.client('s3')
sns = boto3.client('sns')

BUCKET_NAME = 'awsiotlambadamqtts3'  # your bucket name
SNS_TOPIC_ARN = 'arn:aws:sns:us-east-1:106870842661:awsiotlambadamqtts3'  # correct SNS topic ARN

def send_data_to_s3(data):
    file_name = f'iot_data/{datetime.utcnow().isoformat()}_{uuid.uuid4()}.json'
    s3.put_object(
        Bucket=BUCKET_NAME,
        Key=file_name,
        Body=json.dumps(data),
        ContentType='application/json'
    )
    print(f"Data saved to {file_name}")
    return file_name

def notify_sns(data):
    message = {
        'message': 'New IoT data received.',
        'data': data
    }
    sns.publish(
        TopicArn=SNS_TOPIC_ARN,
        Subject='New IoT Data Received',
        Message=json.dumps(message)
    )
    print("SNS notification sent.")

def lambda_handler(event, context):
    try:
        print("Received event:", json.dumps(event))
        
        file_path = send_data_to_s3(event)  # capture file path if needed
        
        notify_sns(event)
        
        return {
            'statusCode': 200,
            'body': json.dumps('Data saved to S3 and notification sent.')
        }
    except Exception as e:
        print("Error:", str(e))
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error: {str(e)}')
        }
